package com.example.retrofit_post.Model;

public class Address {
    String street;
    String suite;
    String city;
    String zipcode;


    public String getStreet() {
        return street;
    }

    public String getSuite() {
        return suite;
    }

    public String getCity() {
        return city;
    }

    public String getZipcode() {
        return zipcode;
    }


}
